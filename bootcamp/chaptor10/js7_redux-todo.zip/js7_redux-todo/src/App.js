import React from 'react';
import Routes from './routes';
import Todo from './components/Todo';

function App() {
  return (
    <div className="App">
      {/* <Todo/> */}
      <Routes/>
    </div>
  );
}

export default App;
