import React from 'react'
import { Route, Router, Switch } from 'react-router-dom'
import {createBrowserHistory} from 'history'

export const history = createBrowserHistory();
export default function Routes() {
    return (
       <Router history = {history}>
         <Switch>
            <Route path = "/hello">
              Hello Router
            </Route>
            
            <Route path ="/qwerty">
              qwerty
            </Route>

            <Route
            path = "aktan"
            component = {() => <h1>Hello Aktan</h1>}/>
            <Route component = {() => <h1>Error:404</h1>}/>
         </Switch>
       </Router>
    )
}
